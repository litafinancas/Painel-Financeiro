# Painel Financeiro (PWA)

App web instalável no celular, na paleta Burgundy Red e Powder Blue.

## Como colocar no ar em 10 minutos (Vercel)

1. Crie uma conta gratuita em https://github.com e outra em https://vercel.com (pode entrar com o GitHub).
2. No GitHub, clique em "New repository", dê o nome `painel-financeiro` e crie.
3. Envie esta pasta inteira para o repositório. O jeito mais fácil sem instalar nada: na página do repositório, clique em "uploading an existing file", arraste todos os arquivos e pastas (menos a pasta `node_modules`, se existir) e clique em "Commit changes".
4. Na Vercel, clique em "Add New Project", escolha o repositório `painel-financeiro` e clique em "Deploy". A Vercel reconhece o Vite sozinha.
5. Em 1 ou 2 minutos aparece o link do app, algo como `painel-financeiro.vercel.app`.

## Instalar no celular

- iPhone: abra o link no Safari, toque no botão de compartilhar e escolha "Adicionar à Tela de Início".
- Android: abra no Chrome, toque nos três pontinhos e escolha "Instalar app" ou "Adicionar à tela inicial".

## Seus dados

Tudo fica salvo no próprio celular. Se trocar de aparelho ou limpar o navegador, use o botão "Fazer backup" no Painel para baixar um arquivo e "Restaurar" no aparelho novo.

## Rodar no computador (opcional)

```
npm install
npm run dev
```
