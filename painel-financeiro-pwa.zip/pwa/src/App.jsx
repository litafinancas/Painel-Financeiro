import { useState, useEffect, useMemo } from "react";

const BURG = "#691D27";
const BURG_DEEP = "#4E141C";
const POWDER = "#BCCED6";
const POWDER_LIGHT = "#E4ECF0";
const ROSE = "#EBDCDF";
const PAPER = "#F8F6F3";
const INK = "#2B1A1D";
const MUTED = "#7C6A6E";

const CATS = ["Essenciais", "Não Essenciais", "Economias", "Dívidas"];
const PAG = ["Pix", "Dinheiro", "Débito", "Crédito", "Boleto"];
const KEY = "financeiro:v1";

const today = () => new Date().toISOString().slice(0, 10);
const firstOfMonth = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10); };
const lastOfMonth = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10); };
const brl = (v) => (Number(v) || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const fmtDate = (s) => (s ? s.split("-").reverse().join("/") : "");
const daysUntil = (s) => Math.round((new Date(s + "T00:00:00") - new Date(today() + "T00:00:00")) / 86400000);
const uid = () => Math.random().toString(36).slice(2, 9);

const EMPTY = {
  inicio: firstOfMonth(), fim: lastOfMonth(),
  rendaPrevista: 2800,
  pct: { Essenciais: 55, "Não Essenciais": 10, Economias: 20, Dívidas: 15 },
  lancamentos: [], contas: [], metas: [], cartao: [], tarefas: [],
};

export default function App() {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("painel");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const r = localStorage.getItem(KEY);
        setData(r ? { ...EMPTY, ...JSON.parse(r) } : EMPTY);
      } catch { setData(EMPTY); }
    })();
  }, []);

  const update = (patch) => {
    setData((d) => {
      const n = typeof patch === "function" ? patch(d) : { ...d, ...patch };
      setSaving(true);
      try { localStorage.setItem(KEY, JSON.stringify(n)); } catch {}
      setTimeout(() => setSaving(false), 400);
      return n;
    });
  };

  if (!data) return <div className="min-h-screen flex items-center justify-center" style={{ background: PAPER, color: MUTED, fontFamily: "Georgia, serif" }}>Abrindo seu painel…</div>;

  const tabs = [["painel", "Painel"], ["lanc", "Lançamentos"], ["contas", "Contas"], ["cartao", "Cartão"], ["metas", "Metas"], ["tarefas", "Tarefas"]];

  return (
    <div className="min-h-screen pb-24" style={{ background: PAPER, color: INK, fontFamily: "system-ui, -apple-system, sans-serif" }}>
      <style>{`
        .serif{font-family:Georgia,'Times New Roman',serif}
        input,select{background:#fff;border:1px solid ${POWDER};border-radius:10px;padding:10px 12px;font-size:14px;color:${INK};width:100%;outline:none}
        input:focus,select:focus{border-color:${BURG};box-shadow:0 0 0 3px ${ROSE}}
        .btn{background:${BURG};color:#fff;border:none;border-radius:10px;padding:11px 16px;font-weight:600;font-size:14px;cursor:pointer}
        .btn:focus-visible{outline:3px solid ${POWDER}}
        .ghost{background:${POWDER_LIGHT};color:${BURG};border:none;border-radius:8px;padding:6px 10px;font-size:12px;font-weight:600;cursor:pointer}
        .card{background:#fff;border-radius:16px;padding:16px;border:1px solid ${POWDER_LIGHT}}
        .pill{font-size:11px;font-weight:600;border-radius:999px;padding:3px 9px}
        @media (prefers-reduced-motion:no-preference){.bar{transition:width .4s ease}}
      `}</style>

      {tab === "painel" && <Painel data={data} update={update} />}
      {tab === "lanc" && <Lancamentos data={data} update={update} />}
      {tab === "contas" && <Contas data={data} update={update} />}
      {tab === "cartao" && <Cartao data={data} update={update} />}
      {tab === "metas" && <Metas data={data} update={update} />}
      {tab === "tarefas" && <Tarefas data={data} update={update} />}

      <nav className="fixed bottom-0 left-0 right-0 flex justify-around px-1 py-2" style={{ background: "#fff", borderTop: `1px solid ${POWDER}` }} aria-label="Seções">
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className="flex-1 py-1 text-xs font-semibold rounded-lg"
            style={{ color: tab === k ? BURG : MUTED, background: tab === k ? ROSE : "transparent", border: "none" }}>{l}</button>
        ))}
      </nav>
      {saving && <div className="fixed top-2 right-2 text-xs px-2 py-1 rounded-full" style={{ background: POWDER, color: BURG }}>salvando</div>}
    </div>
  );
}

function useResumo(data) {
  return useMemo(() => {
    const inPeriod = (l) => l.data >= data.inicio && l.data <= data.fim;
    const ls = data.lancamentos.filter(inPeriod);
    const sum = (cat) => ls.filter((l) => l.categoria === cat).reduce((a, l) => a + Number(l.valor), 0);
    const entradas = sum("Renda");
    const real = Object.fromEntries(CATS.map((c) => [c, sum(c)]));
    const gastos = real.Essenciais + real["Não Essenciais"] + real.Dívidas;
    const saldo = entradas - gastos - real.Economias;
    const orc = Object.fromEntries(CATS.map((c) => [c, (data.rendaPrevista * (data.pct[c] || 0)) / 100]));
    return { entradas, real, gastos, saldo, orc, guardado: real.Economias };
  }, [data]);
}

function Header({ title, sub, children }) {
  return (
    <header className="px-5 pt-8 pb-6" style={{ background: BURG, color: "#fff", borderRadius: "0 0 28px 28px" }}>
      <p className="text-sm" style={{ color: POWDER }}>{sub}</p>
      <h1 className="serif text-2xl mt-1">{title}</h1>
      {children}
    </header>
  );
}

function Painel({ data, update }) {
  const r = useResumo(data);
  const [edit, setEdit] = useState(false);
  const proximas = data.contas.filter((c) => !c.pago).map((c) => ({ ...c, dias: daysUntil(c.vencimento) })).sort((a, b) => a.dias - b.dias).slice(0, 4);
  const totalPct = CATS.reduce((a, c) => a + Number(data.pct[c] || 0), 0);

  return (
    <div>
      <Header sub={`${fmtDate(data.inicio)} a ${fmtDate(data.fim)}`} title="Seu mês em um olhar">
        <div className="mt-5">
          <p className="text-xs" style={{ color: POWDER }}>Sobra depois de pagar tudo e guardar</p>
          <p className="serif" style={{ fontSize: 44, lineHeight: 1.1 }}>{brl(r.saldo)}</p>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-5 text-sm">
          {[["Entrou", r.entradas], ["Saiu", r.gastos], ["Guardou", r.guardado]].map(([l, v]) => (
            <div key={l} className="rounded-xl p-3" style={{ background: BURG_DEEP }}>
              <p className="text-xs" style={{ color: POWDER }}>{l}</p>
              <p className="serif text-lg">{brl(v)}</p>
            </div>
          ))}
        </div>
      </Header>

      <section className="px-4 mt-5 space-y-4">
        <div className="card">
          <div className="flex justify-between items-center mb-3">
            <h2 className="serif text-lg">Como o dinheiro se dividiu</h2>
            <button className="ghost" onClick={() => setEdit(!edit)}>{edit ? "Fechar" : "Ajustar"}</button>
          </div>
          {edit && (
            <div className="space-y-2 mb-4 p-3 rounded-xl" style={{ background: POWDER_LIGHT }}>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-xs">Início<input type="date" value={data.inicio} onChange={(e) => update({ inicio: e.target.value })} /></label>
                <label className="text-xs">Fim<input type="date" value={data.fim} onChange={(e) => update({ fim: e.target.value })} /></label>
              </div>
              <label className="text-xs">Renda prevista no mês<input type="number" value={data.rendaPrevista} onChange={(e) => update({ rendaPrevista: Number(e.target.value) })} /></label>
              <div className="grid grid-cols-2 gap-2">
                {CATS.map((c) => (
                  <label key={c} className="text-xs">{c} (%)<input type="number" value={data.pct[c]} onChange={(e) => update({ pct: { ...data.pct, [c]: Number(e.target.value) } })} /></label>
                ))}
              </div>
              <p className="text-xs" style={{ color: totalPct === 100 ? BURG : "#B3261E" }}>{totalPct === 100 ? "Fecha em 100%" : `Soma ${totalPct}%, ajuste para 100%`}</p>
            </div>
          )}
          {CATS.map((c) => {
            const pct = r.orc[c] ? Math.min(100, (r.real[c] / r.orc[c]) * 100) : 0;
            const over = r.real[c] > r.orc[c];
            return (
              <div key={c} className="mb-3">
                <div className="flex justify-between text-sm"><span>{c}</span><span style={{ color: MUTED }}>{brl(r.real[c])} de {brl(r.orc[c])}</span></div>
                <div className="h-2 rounded-full mt-1" style={{ background: POWDER_LIGHT }}>
                  <div className="bar h-2 rounded-full" style={{ width: `${pct}%`, background: over ? "#B3261E" : c === "Economias" ? "#6F8A99" : BURG }} />
                </div>
                {over && <p className="text-xs mt-1" style={{ color: "#B3261E" }}>Passou {brl(r.real[c] - r.orc[c])} do planejado</p>}
              </div>
            );
          })}
        </div>

        <div className="card">
          <h2 className="serif text-lg mb-2">Próximas contas</h2>
          {proximas.length === 0 && <p className="text-sm" style={{ color: MUTED }}>Nenhuma conta pendente. Cadastre na aba Contas.</p>}
          {proximas.map((c) => (
            <div key={c.id} className="flex justify-between items-center py-2 text-sm" style={{ borderBottom: `1px solid ${POWDER_LIGHT}` }}>
              <div><p>{c.nome}</p><p className="text-xs" style={{ color: MUTED }}>{fmtDate(c.vencimento)}</p></div>
              <div className="text-right"><p>{brl(c.valor)}</p><StatusConta dias={c.dias} /></div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button className="ghost" onClick={() => {
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
            const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "backup-financas.json"; a.click();
          }}>Fazer backup</button>
          <label className="ghost text-center cursor-pointer">Restaurar
            <input type="file" accept="application/json" className="hidden" onChange={(e) => {
              const file = e.target.files[0]; if (!file) return;
              file.text().then((t) => { try { update({ ...EMPTY, ...JSON.parse(t) }); } catch { alert("Arquivo inválido"); } });
            }} />
          </label>
          <button className="ghost" style={{ color: MUTED, background: "transparent" }} onClick={() => { if (confirm("Apagar todos os dados do app?")) update(EMPTY); }}>Começar do zero</button>
        </div>
      </section>
    </div>
  );
}

function StatusConta({ dias }) {
  const s = dias < 0 ? ["Atrasada", "#F3C9CC", "#7A1F28"] : dias <= 3 ? ["Vence em breve", ROSE, BURG] : ["Em dia", POWDER_LIGHT, "#4D6B7A"];
  return <span className="pill" style={{ background: s[1], color: s[2] }}>{s[0]}</span>;
}

function Lancamentos({ data, update }) {
  const [f, setF] = useState({ data: today(), descricao: "", categoria: "Essenciais", pagamento: "Pix", valor: "" });
  const [filtro, setFiltro] = useState("Todos");
  const add = () => {
    if (!f.descricao || !f.valor) return;
    update((d) => ({ ...d, lancamentos: [{ ...f, id: uid(), valor: Number(f.valor) }, ...d.lancamentos] }));
    setF({ ...f, descricao: "", valor: "" });
  };
  const del = (id) => update((d) => ({ ...d, lancamentos: d.lancamentos.filter((l) => l.id !== id) }));
  const lista = data.lancamentos
    .filter((l) => filtro === "Todos" || (filtro === "Essencial" ? l.categoria === "Essenciais" : filtro === "Não essencial" ? l.categoria === "Não Essenciais" : l.pagamento === filtro))
    .sort((a, b) => b.data.localeCompare(a.data));
  const total = lista.filter((l) => l.categoria !== "Renda").reduce((a, l) => a + l.valor, 0);

  return (
    <div>
      <Header sub="Tudo que entra e sai" title="Lançamentos">
        <div className="mt-4 space-y-2">
          <input placeholder="O que foi? Ex: mercado, salário" value={f.descricao} onChange={(e) => setF({ ...f, descricao: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input type="number" placeholder="Valor" value={f.valor} onChange={(e) => setF({ ...f, valor: e.target.value })} />
            <input type="date" value={f.data} onChange={(e) => setF({ ...f, data: e.target.value })} />
            <select value={f.categoria} onChange={(e) => setF({ ...f, categoria: e.target.value })}>{["Renda", ...CATS].map((c) => <option key={c}>{c}</option>)}</select>
            <select value={f.pagamento} onChange={(e) => setF({ ...f, pagamento: e.target.value })}>{PAG.map((c) => <option key={c}>{c}</option>)}</select>
          </div>
          <button className="btn w-full" style={{ background: POWDER, color: BURG }} onClick={add}>Registrar</button>
        </div>
      </Header>
      <section className="px-4 mt-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {["Todos", "Essencial", "Não essencial", ...PAG].map((p) => (
            <button key={p} className="ghost whitespace-nowrap" style={filtro === p ? { background: BURG, color: "#fff" } : {}} onClick={() => setFiltro(p)}>{p}</button>
          ))}
        </div>
        <p className="text-xs my-2" style={{ color: MUTED }}>{lista.length} lançamentos, {brl(total)} em saídas</p>
        {lista.length === 0 && <p className="card text-sm" style={{ color: MUTED }}>Nada por aqui ainda. Registre o primeiro lançamento acima.</p>}
        {lista.map((l) => (
          <div key={l.id} className="card flex justify-between items-center mb-2 py-3">
            <div>
              <p className="text-sm">{l.descricao}</p>
              <p className="text-xs" style={{ color: MUTED }}>{fmtDate(l.data)} · {l.categoria} · {l.pagamento}</p>
            </div>
            <div className="text-right">
              <p className="serif" style={{ color: l.categoria === "Renda" ? "#4D6B7A" : BURG }}>{l.categoria === "Renda" ? "+" : "-"}{brl(l.valor)}</p>
              <button className="text-xs" style={{ color: MUTED, background: "none", border: "none" }} onClick={() => del(l.id)}>apagar</button>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

function Contas({ data, update }) {
  const [f, setF] = useState({ nome: "", valor: "", vencimento: today() });
  const add = () => {
    if (!f.nome || !f.valor) return;
    update((d) => ({ ...d, contas: [...d.contas, { ...f, id: uid(), valor: Number(f.valor), pago: false }] }));
    setF({ nome: "", valor: "", vencimento: today() });
  };
  const toggle = (id) => update((d) => ({ ...d, contas: d.contas.map((c) => (c.id === id ? { ...c, pago: !c.pago } : c)) }));
  const del = (id) => update((d) => ({ ...d, contas: d.contas.filter((c) => c.id !== id) }));
  const pend = data.contas.filter((c) => !c.pago).reduce((a, c) => a + c.valor, 0);
  const lista = [...data.contas].sort((a, b) => a.pago - b.pago || a.vencimento.localeCompare(b.vencimento));

  return (
    <div>
      <Header sub="Calendário de vencimentos" title={`${brl(pend)} a pagar`}>
        <div className="mt-4 space-y-2">
          <input placeholder="Conta. Ex: aluguel, internet" value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input type="number" placeholder="Valor" value={f.valor} onChange={(e) => setF({ ...f, valor: e.target.value })} />
            <input type="date" value={f.vencimento} onChange={(e) => setF({ ...f, vencimento: e.target.value })} />
          </div>
          <button className="btn w-full" style={{ background: POWDER, color: BURG }} onClick={add}>Adicionar conta</button>
        </div>
      </Header>
      <section className="px-4 mt-4">
        {lista.length === 0 && <p className="card text-sm" style={{ color: MUTED }}>Cadastre suas contas fixas para ver o que vence e quando.</p>}
        {lista.map((c) => (
          <div key={c.id} className="card flex items-center gap-3 mb-2 py-3" style={{ opacity: c.pago ? 0.55 : 1 }}>
            <button aria-label={c.pago ? "Marcar como pendente" : "Marcar como paga"} onClick={() => toggle(c.id)} className="w-6 h-6 rounded-full flex-shrink-0" style={{ border: `2px solid ${BURG}`, background: c.pago ? BURG : "#fff", color: "#fff", fontSize: 12 }}>{c.pago ? "✓" : ""}</button>
            <div className="flex-1">
              <p className="text-sm" style={{ textDecoration: c.pago ? "line-through" : "none" }}>{c.nome}</p>
              <p className="text-xs" style={{ color: MUTED }}>{fmtDate(c.vencimento)}</p>
            </div>
            <div className="text-right">
              <p className="serif">{brl(c.valor)}</p>
              {c.pago ? <span className="pill" style={{ background: POWDER_LIGHT, color: "#4D6B7A" }}>Paga</span> : <StatusConta dias={daysUntil(c.vencimento)} />}
            </div>
            <button className="text-xs" style={{ color: MUTED, background: "none", border: "none" }} onClick={() => del(c.id)}>×</button>
          </div>
        ))}
      </section>
    </div>
  );
}

function Cartao({ data, update }) {
  const [f, setF] = useState({ compra: "", valor: "", parcelas: 1, data: today() });
  const add = () => {
    if (!f.compra || !f.valor) return;
    update((d) => ({ ...d, cartao: [{ ...f, id: uid(), valor: Number(f.valor), parcelas: Number(f.parcelas) || 1 }, ...d.cartao] }));
    setF({ compra: "", valor: "", parcelas: 1, data: today() });
  };
  const del = (id) => update((d) => ({ ...d, cartao: d.cartao.filter((c) => c.id !== id) }));
  const meses = useMemo(() => {
    const now = new Date(); const out = [];
    for (let i = 0; i < 6; i++) {
      const m = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const label = m.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
      let total = 0;
      data.cartao.forEach((c) => {
        const d = new Date(c.data + "T00:00:00");
        const start = new Date(d.getFullYear(), d.getMonth() + 1, 1);
        const idx = (m.getFullYear() - start.getFullYear()) * 12 + (m.getMonth() - start.getMonth());
        if (idx >= 0 && idx < c.parcelas) total += c.valor / c.parcelas;
      });
      out.push({ label, total });
    }
    return out;
  }, [data.cartao]);
  const max = Math.max(1, ...meses.map((m) => m.total));

  return (
    <div>
      <Header sub="Parcelas caem sozinhas nos próximos meses" title="Cartão de crédito">
        <div className="mt-4 space-y-2">
          <input placeholder="Compra. Ex: tênis" value={f.compra} onChange={(e) => setF({ ...f, compra: e.target.value })} />
          <div className="grid grid-cols-3 gap-2">
            <input type="number" placeholder="Valor total" value={f.valor} onChange={(e) => setF({ ...f, valor: e.target.value })} />
            <input type="number" min="1" placeholder="Parcelas" value={f.parcelas} onChange={(e) => setF({ ...f, parcelas: e.target.value })} />
            <input type="date" value={f.data} onChange={(e) => setF({ ...f, data: e.target.value })} />
          </div>
          <button className="btn w-full" style={{ background: POWDER, color: BURG }} onClick={add}>Adicionar compra</button>
        </div>
      </Header>
      <section className="px-4 mt-4 space-y-4">
        <div className="card">
          <h2 className="serif text-lg mb-3">Fatura prevista</h2>
          <div className="flex items-end gap-2 h-32">
            {meses.map((m) => (
              <div key={m.label} className="flex-1 flex flex-col items-center justify-end h-full">
                <p className="text-xs mb-1" style={{ color: MUTED }}>{brl(m.total).replace(",00", "")}</p>
                <div className="bar w-full rounded-t-lg" style={{ height: `${(m.total / max) * 80}%`, background: BURG, minHeight: m.total ? 4 : 0 }} />
                <p className="text-xs mt-1">{m.label}</p>
              </div>
            ))}
          </div>
        </div>
        {data.cartao.map((c) => (
          <div key={c.id} className="card flex justify-between items-center py-3">
            <div><p className="text-sm">{c.compra}</p><p className="text-xs" style={{ color: MUTED }}>{fmtDate(c.data)} · {c.parcelas}x de {brl(c.valor / c.parcelas)}</p></div>
            <div className="text-right"><p className="serif">{brl(c.valor)}</p><button className="text-xs" style={{ color: MUTED, background: "none", border: "none" }} onClick={() => del(c.id)}>apagar</button></div>
          </div>
        ))}
      </section>
    </div>
  );
}

function Metas({ data, update }) {
  const [f, setF] = useState({ nome: "", alvo: "", guardado: "", prazo: "" });
  const add = () => {
    if (!f.nome || !f.alvo) return;
    update((d) => ({ ...d, metas: [...d.metas, { ...f, id: uid(), alvo: Number(f.alvo), guardado: Number(f.guardado) || 0 }] }));
    setF({ nome: "", alvo: "", guardado: "", prazo: "" });
  };
  const depositar = (id) => {
    const v = Number(prompt("Quanto você guardou agora?"));
    if (v) update((d) => ({ ...d, metas: d.metas.map((m) => (m.id === id ? { ...m, guardado: m.guardado + v } : m)) }));
  };
  const del = (id) => update((d) => ({ ...d, metas: d.metas.filter((m) => m.id !== id) }));

  return (
    <div>
      <Header sub="Objetivos que viram conquistas" title="Metas">
        <div className="mt-4 space-y-2">
          <input placeholder="Meta. Ex: viagem, reserva de emergência" value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
          <div className="grid grid-cols-3 gap-2">
            <input type="number" placeholder="Objetivo" value={f.alvo} onChange={(e) => setF({ ...f, alvo: e.target.value })} />
            <input type="number" placeholder="Já tenho" value={f.guardado} onChange={(e) => setF({ ...f, guardado: e.target.value })} />
            <input type="date" value={f.prazo} onChange={(e) => setF({ ...f, prazo: e.target.value })} />
          </div>
          <button className="btn w-full" style={{ background: POWDER, color: BURG }} onClick={add}>Criar meta</button>
        </div>
      </Header>
      <section className="px-4 mt-4 space-y-3">
        {data.metas.length === 0 && <p className="card text-sm" style={{ color: MUTED }}>Crie sua primeira meta. Uma reserva de emergência é um ótimo começo.</p>}
        {data.metas.map((m) => {
          const pct = Math.min(100, (m.guardado / m.alvo) * 100);
          const falta = Math.max(0, m.alvo - m.guardado);
          const meses = m.prazo ? Math.max(1, Math.round(daysUntil(m.prazo) / 30)) : null;
          return (
            <div key={m.id} className="card">
              <div className="flex justify-between items-start">
                <div><h3 className="serif text-lg">{m.nome}</h3><p className="text-xs" style={{ color: MUTED }}>{m.prazo ? `até ${fmtDate(m.prazo)}` : "sem prazo"}</p></div>
                <p className="serif text-lg">{Math.round(pct)}%</p>
              </div>
              <div className="h-3 rounded-full my-3" style={{ background: POWDER_LIGHT }}><div className="bar h-3 rounded-full" style={{ width: `${pct}%`, background: pct >= 100 ? "#6F8A99" : BURG }} /></div>
              <p className="text-sm">{brl(m.guardado)} de {brl(m.alvo)}</p>
              {falta > 0 && meses && <p className="text-xs mt-1" style={{ color: MUTED }}>Guardar {brl(falta / meses)} por mês para chegar no prazo</p>}
              {falta === 0 && <p className="text-xs mt-1" style={{ color: "#4D6B7A" }}>Meta concluída</p>}
              <div className="flex gap-2 mt-3">
                <button className="ghost" onClick={() => depositar(m.id)}>Registrar depósito</button>
                <button className="ghost" style={{ background: "transparent", color: MUTED }} onClick={() => del(m.id)}>Excluir</button>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}

function Tarefas({ data, update }) {
  const [f, setF] = useState({ nome: "", prazo: "", prioridade: "Média" });
  const add = () => {
    if (!f.nome) return;
    update((d) => ({ ...d, tarefas: [...d.tarefas, { ...f, id: uid(), feita: false }] }));
    setF({ nome: "", prazo: "", prioridade: "Média" });
  };
  const toggle = (id) => update((d) => ({ ...d, tarefas: d.tarefas.map((t) => (t.id === id ? { ...t, feita: !t.feita } : t)) }));
  const del = (id) => update((d) => ({ ...d, tarefas: d.tarefas.filter((t) => t.id !== id) }));
  const ordem = { Alta: 0, Média: 1, Baixa: 2 };
  const lista = [...data.tarefas].sort((a, b) => a.feita - b.feita || ordem[a.prioridade] - ordem[b.prioridade] || (a.prazo || "9").localeCompare(b.prazo || "9"));
  const pend = data.tarefas.filter((t) => !t.feita).length;

  return (
    <div>
      <Header sub="Rastreador de tarefas" title={pend === 0 ? "Tudo em dia" : `${pend} para fazer`}>
        <div className="mt-4 space-y-2">
          <input placeholder="Tarefa. Ex: post do SEDHIR, devocional" value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input type="date" value={f.prazo} onChange={(e) => setF({ ...f, prazo: e.target.value })} />
            <select value={f.prioridade} onChange={(e) => setF({ ...f, prioridade: e.target.value })}>{["Alta", "Média", "Baixa"].map((p) => <option key={p}>{p}</option>)}</select>
          </div>
          <button className="btn w-full" style={{ background: POWDER, color: BURG }} onClick={add}>Adicionar tarefa</button>
        </div>
      </Header>
      <section className="px-4 mt-4">
        {lista.length === 0 && <p className="card text-sm" style={{ color: MUTED }}>Sem tarefas. Anote a próxima coisa que precisa sair da cabeça.</p>}
        {lista.map((t) => {
          const d = t.prazo ? daysUntil(t.prazo) : null;
          return (
            <div key={t.id} className="card flex items-center gap-3 mb-2 py-3" style={{ opacity: t.feita ? 0.55 : 1 }}>
              <button aria-label={t.feita ? "Reabrir" : "Concluir"} onClick={() => toggle(t.id)} className="w-6 h-6 rounded-full flex-shrink-0" style={{ border: `2px solid ${BURG}`, background: t.feita ? BURG : "#fff", color: "#fff", fontSize: 12 }}>{t.feita ? "✓" : ""}</button>
              <div className="flex-1">
                <p className="text-sm" style={{ textDecoration: t.feita ? "line-through" : "none" }}>{t.nome}</p>
                <p className="text-xs" style={{ color: MUTED }}>{t.prazo ? fmtDate(t.prazo) : "sem prazo"} · prioridade {t.prioridade.toLowerCase()}</p>
              </div>
              {!t.feita && d !== null && <span className="pill" style={{ background: d < 0 ? "#F3C9CC" : d <= 2 ? ROSE : POWDER_LIGHT, color: d < 0 ? "#7A1F28" : d <= 2 ? BURG : "#4D6B7A" }}>{d < 0 ? "Atrasada" : d === 0 ? "Hoje" : d <= 2 ? "Urgente" : "No prazo"}</span>}
              <button className="text-xs" style={{ color: MUTED, background: "none", border: "none" }} onClick={() => del(t.id)}>×</button>
            </div>
          );
        })}
      </section>
    </div>
  );
}
